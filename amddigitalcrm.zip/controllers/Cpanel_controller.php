<?php

class Cpanel_controller extends Controller {

    function __construct() {
        parent::__construct();
    }

    public function Home() {
        $this->view->render($this, 'home', NOMBRE_EMPRESA, 'home');
    }

    public function Home2() {
        $this->view->render($this, 'home2', NOMBRE_EMPRESA, 'home2');
    }

    public function Login() {
        $this->view->render($this, 'login', NOMBRE_EMPRESA, 'login');
    }

    public function ClientesGeneral() {
        $this->view->render($this, 'clientes_general', NOMBRE_EMPRESA, 'clientes_general');
    }

    public function MisClientes() {
        $this->view->render($this, 'mis_clientes', NOMBRE_EMPRESA, 'mis_clientes');
    }

    public function PanelCliente() {
        $this->view->render($this, 'panel_cliente', NOMBRE_EMPRESA, 'panel_cliente');
    }

}
