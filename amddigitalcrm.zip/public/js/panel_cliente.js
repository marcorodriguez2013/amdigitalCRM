$(document).ready(function() {
    tinymce.init({
     selector: '#mytextarea'
 });
    const app = new Vue({
        el: '#app',
        data: {
            correos: [],
        },
        created: function() {
            var url = URLPRINCIPAL + 'PanelCliente/LlamarCorreos/1/1';
            this.$http.get(url).then(response => {
                this.correos = response.body;
                console.log(response.body);
            }, response => {
                console.log(response);
            });
        },
        computed: {}
    });
})